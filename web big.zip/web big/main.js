const nav = document.querySelector('.nav')
window.addEventListener('scroll', fixNav)

function fixNav() {
    if(window.scrollY > nav.offsetHeight + 150) {
        nav.classList.add('active')
    } else {
        nav.classList.remove('active')
    }
}

var i = 0;
var images = ['image/HECTF2023.png', 'image/ISCTF2023.png', 'image/PCTF2023.png'];
var texts = ['HECTF', 'ISCTF', 'PCTF'];

function changeImg() {
    document.getElementById('slideImg').src = images[i];
    document.getElementById('text').innerText = texts[i];
    i++;
    if (i >= images.length) {
        i = 0;
    }
}

// 设置定时器，每隔一定时间切换图片和文字
var intervalId = setInterval(changeImg, 3000);


// 页面加载时显示第一张图片和对应的文字
window.onload = function() {
    document.getElementById('slideImg').src = images[0];
    document.getElementById('text').innerText = texts[0];
};