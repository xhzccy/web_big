// 获取比赛结束时间（假设为 2023 年 12 月 31 日 23:59:59）
const endTime = new Date('2023-12-31T23:59:59').getTime();

// 更新倒计时
function updateCountdown() {
    const currentTime = new Date().getTime();
    const timeDifference = endTime - currentTime;

    const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
    const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);

    document.getElementById('countdown').innerHTML = `${days} 天 ${hours} 小时 ${minutes} 分钟 ${seconds} 秒`;

    if (timeDifference < 0) {
        document.getElementById('countdown').innerHTML = '比赛已结束';
    }
}

// 每秒更新一次倒计时
setInterval(updateCountdown, 1000);

// 页面加载时立即更新倒计时
updateCountdown();