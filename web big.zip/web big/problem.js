function showPage(pageNumber) {
    // 隐藏所有页面
    var pages = document.getElementsByClassName("page");
    for (var i = 0; i < pages.length; i++) {
        pages[i].classList.remove("active");
    }

    // 显示选中的页面
    var selectedPage = document.getElementById("page" + pageNumber);
    selectedPage.classList.add("active");
}